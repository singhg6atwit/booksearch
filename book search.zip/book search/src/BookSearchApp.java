import javax.swing.*;

public class BookSearchApp {
    private JFrame frame;

    public void run() {
        frame = new JFrame("Book Search");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);

        // Create and add the search panel
        SearchPanel searchPanel = new SearchPanel();
        frame.getContentPane().add(searchPanel);

        frame.setVisible(true);
    }
}
