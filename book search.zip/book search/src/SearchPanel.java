import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class SearchPanel extends JPanel {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField searchField;
    private JTable resultsTable;

    public SearchPanel() {
        setLayout(new BorderLayout());

        // Create and add the search bar
        JPanel searchPanel = new JPanel(new FlowLayout());
        JLabel searchLabel = new JLabel("Search: ");
        searchField = new JTextField(20);
        searchPanel.add(searchLabel);
        searchPanel.add(searchField);
        add(searchPanel, BorderLayout.NORTH);

        // Create and add the results table
        String[] columnNames = {"Title", "Author", "Year"};
        Object[][] data = {};
        DefaultTableModel model = new DefaultTableModel(data, columnNames);
        resultsTable = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(resultsTable);
        add(scrollPane, BorderLayout.CENTER);
    }

    public void setResults(List<Book> books) {
        DefaultTableModel model = (DefaultTableModel) resultsTable.getModel();
        model.setRowCount(0);

        for (Book book : books) {
            Object[] row = {book.getTitle(), book.getAuthor(), book.getYear()};
            model.addRow(row);
        }
    }

    public String getSearchText() {
        return searchField.getText();
    }
}
